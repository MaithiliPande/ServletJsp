package com.yash.loginapp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class UserDashboard
 */
public class UserDashboard extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String filename=getServletContext().getInitParameter("messages");
		Properties properties = new Properties();
		properties.load(getClass().getClassLoader().getResourceAsStream(filename));
		String email=request.getParameter("emailid");
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Welcom Page</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<form action='UserController'>");
		out.println("<table>");
		out.println("<tr>");
		out.println("<td>"+"<h2>Welcome "+email+"</h2>"+"</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>"+properties.getProperty("loginSuccess"));
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>"+"<input type='submit' name='logout' value='Logout'>"+"</td>");
		out.println("</tr>");
		out.println("</table>");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}

}
