package com.yash.loginapp.serviceimpl;

import java.util.LinkedList;
import java.util.List;

import com.yash.loginapp.pojo.UserCommand;

public class UserServiceImpl {
	public List<UserCommand> userRepository=new LinkedList<UserCommand>();

	public UserServiceImpl() {
		userRepository.add(new UserCommand("maithili@yash.com","maithili123"));
		userRepository.add(new UserCommand("rewati@gmail.com","rewati001"));
		userRepository.add(new UserCommand("rupal@yahoo.com","rupal06"));
	}
	 
	public boolean authenticateUser(String emailId,String pwd) {
		for (UserCommand user : userRepository) {
			if(user.getEmail().equalsIgnoreCase(emailId)&& user.getPassword().equalsIgnoreCase(pwd))
			{
				return true;
			}
		}
		return  false;
	 }
	
	

}
