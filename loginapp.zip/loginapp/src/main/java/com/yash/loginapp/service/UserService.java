package com.yash.loginapp.service;

public interface UserService {
	public void authenticateUser(String emailId,String pwd);
	
}
