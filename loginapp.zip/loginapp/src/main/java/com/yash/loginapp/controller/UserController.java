package com.yash.loginapp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.loginapp.serviceimpl.UserServiceImpl;


public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    UserServiceImpl service=new UserServiceImpl();
    
    
   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String msg=(String) request.getAttribute("error");
		System.out.println(msg);
		if(msg!=null) {out.println(msg);}
		out.println("<html>");
		out.println("<head>");
		
		out.println("<title>Login page</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<form action='UserController' method='post'>");
		out.println("<table>");
		out.println("<tr>");
		out.println("<td>Email :</td>");
		out.println("<td>"+"<input type='text' name='emailid'>"+"</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>Password :</td>");
		out.println("<td>"+"<input type='password' name='password'>"+"</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td></td>");
		out.println("<td>"+"<input type='submit' name='login' value='Login'>"+"</td>");
		out.println("</tr>");
		out.println("</table>");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
    }
    
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String email=req.getParameter("emailid");
		String password=req.getParameter("password");
		PrintWriter out=resp.getWriter();
		
		
		boolean authentication=service.authenticateUser(email, password);
		if(authentication==true) {
			
			RequestDispatcher rd=req.getRequestDispatcher("UserDashboard");
			rd.forward(req, resp);
		}
		else {
		String filename=getServletContext().getInitParameter("messages");
		Properties properties = new Properties();
		properties.load(getClass().getClassLoader().getResourceAsStream(filename));
		String name=properties.getProperty("loginError");
		System.out.println(name);
		req.setAttribute("error", name);
		
		
	
		
		}
	}

}
