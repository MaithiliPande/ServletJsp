package com.yash.listener;

import javax.servlet.ServletRequest;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class MyServletRequestListener
 *
 */
@WebListener
public class MyServletRequestListener implements ServletRequestListener {

  public static int count=0;
    public void requestDestroyed(ServletRequestEvent servletRequestEvent)  {
    	System.out.println("\n----------------------\n");
    	System.out.println("requestDestroyed method is called in"+this.getClass().getName());
    	ServletRequest servletRequest=servletRequestEvent.getServletRequest();
    	System.out.println(servletRequest+" is destroyed");
    	System.out.println("\n-----------------------\n");
    	
    }

	
    public void requestInitialized(ServletRequestEvent servletRequestEvent)  { 
    	count++;
    	System.out.println("\n----------------------\n");
    	System.out.println("requestInitialized method is called in"+this.getClass().getName());
    	ServletRequest servletRequest=servletRequestEvent.getServletRequest();
    	System.out.println(servletRequest+" is created or initialized");
    	System.out.println("\n-----------------------\n");
    	
    }
	
}
