package com.yash.listener;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class MyServletContextListener
 *
 */
@WebListener
public class MyServletContextListener implements ServletContextListener {

    public void contextDestroyed(ServletContextEvent servletContextEvent)  {
    	System.out.println("\n############\n");
    	System.out.println("contextDestroyed method is called in "+this.getClass().getName());
    	ServletContext servletContext=servletContextEvent.getServletContext();
    	System.out.println(servletContext+" is destroyed");
    	System.out.println("\n############\n");
    }

    public void contextInitialized(ServletContextEvent servletContextEvent)  { 
    	System.out.println("\n############\n");
    	System.out.println("contextinitialized method is called in "+this.getClass().getName());
    	ServletContext servletContext=servletContextEvent.getServletContext();
    	System.out.println(servletContext+" is initialized");
    	System.out.println("\n############\n");
    }
	
}
