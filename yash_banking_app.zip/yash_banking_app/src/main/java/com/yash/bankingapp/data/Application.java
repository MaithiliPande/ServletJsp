package com.yash.bankingapp.data;

import java.util.Date;

import org.hibernate.Session;

import com.yash.bankingapp.domain.User;

public class Application {
	public static void main(String[] args) {
		Session session= HibernateUitl.getSessionFactory().openSession();
		session.getTransaction().begin();
		User user= new User();
		user.setFirstName("Maithili");
		user.setLastName("Pande");
		user.setBirthDate(new Date());
		user.setEmailAddress("maithilipande53@gmail.com");
		user.setLastUpdatedDate(new Date());
		user.setLastUpdatedBy("Maithili");
		user.setCreatedDate(new Date());
		user.setCreatedBy("Maithili");
		session.saveOrUpdate(user);
		session.getTransaction().commit();
		session.close();
	}
}
