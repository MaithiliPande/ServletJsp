package com.yash.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
//	public void init(ServletConfig config) throws ServletException {
//		System.out.println("----------------------------------------------");
//		System.out.println("Init method is called in :"+this.getClass().getName());
//		System.out.println("----------------------------------------------");
//	}
//
//	public void destroy() {
//		System.out.println("----------------------------------------------");
//		System.out.println("Destroy method is called in :"+this.getClass().getName());
//		System.out.println("----------------------------------------------");
//	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String userName=request.getParameter("username");
		out.print("Welcome "+userName);
		
		HttpSession session=request.getSession(true);
		session.setAttribute("uname", userName);
		
		ServletContext ctx=getServletContext();
		int totalUsers=(Integer)ctx.getAttribute("totalusers");
		System.out.println(totalUsers);
		int currentUsers=(Integer) ctx.getAttribute("currentusers");
		System.out.println(currentUsers);
		out.print("<br>Total Users="+totalUsers);
		out.print("<br>Current Users="+currentUsers);
		out.print("<br><a href='logout'>Logout</a>");
		out.close();
	}

}
