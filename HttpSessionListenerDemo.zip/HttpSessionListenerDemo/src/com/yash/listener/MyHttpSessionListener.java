package com.yash.listener;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * Application Lifecycle Listener implementation class MyHttpSessionListener
 *
 */
@WebListener
public class MyHttpSessionListener implements HttpSessionListener {

   
    public void sessionCreated(HttpSessionEvent httpSessionEvent)  { 
    	System.out.println("\n###########################\n");
    	System.out.println("sessionCreated method is called in "+this.getClass().getName());
    	HttpSession session=httpSessionEvent.getSession();
    	System.out.println(session+" is created");
    	System.out.println("Created id:"+session.getId()+" Max inactive interval:"+session.getMaxInactiveInterval());
    	System.out.println("\n###########################\n");
    }

    public void sessionDestroyed(HttpSessionEvent httpSessionEvent)  {
    	System.out.println("\n###########################\n");
    	System.out.println("sessionDestroyed method is called in "+this.getClass().getName());
    	HttpSession session=httpSessionEvent.getSession();
    	System.out.println(session+" is destroyed");
    	System.out.println("Destroyed id:"+session.getId()+" Max inactive interval:"+session.getMaxInactiveInterval());
    	System.out.println("\n###########################\n");
    }
	
}
