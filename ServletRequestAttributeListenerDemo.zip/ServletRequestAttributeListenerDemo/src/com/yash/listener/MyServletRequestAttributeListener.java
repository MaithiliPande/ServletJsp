package com.yash.listener;

import javax.servlet.ServletRequestAttributeEvent;
import javax.servlet.ServletRequestAttributeListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class MyServletRequestAttributeListener
 *
 */
@WebListener
public class MyServletRequestAttributeListener implements ServletRequestAttributeListener {

   
    public void attributeRemoved(ServletRequestAttributeEvent servletRequestAttributeEvent)  {
    	System.out.println("\n#####################\n");
    	System.out.println("attributeRemoved method is called in "+this.getClass().getName());
    	System.out.println("Removed attribute name is :"+servletRequestAttributeEvent.getName()+
    			" value:"+servletRequestAttributeEvent.getValue());
    	System.out.println("\n#####################\n");
    }

	
    public void attributeAdded(ServletRequestAttributeEvent servletRequestAttributeEvent)  { 
    	System.out.println("\n#####################\n");
    	System.out.println("attributeAdded method is called in "+this.getClass().getName());
    	System.out.println("Newly added attribute name is :"+servletRequestAttributeEvent.getName()+
    			" value:"+servletRequestAttributeEvent.getValue());
    	System.out.println("\n#####################\n");
    }

	
    public void attributeReplaced(ServletRequestAttributeEvent servletRequestAttributeEvent)  { 
    	System.out.println("\n#####################\n");
    	System.out.println("attributeReplaced method is called in "+this.getClass().getName());
    	System.out.println("Replaced attribute name is :"+servletRequestAttributeEvent.getName()+
    			" value:"+servletRequestAttributeEvent.getValue());
    	System.out.println("\n#####################\n");
    }
	
}
