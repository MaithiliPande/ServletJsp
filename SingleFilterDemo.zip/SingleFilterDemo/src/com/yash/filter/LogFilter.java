package com.yash.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

/**
 * Servlet Filter implementation class LogFilter
 */

public class LogFilter implements Filter {
	
	public void init(FilterConfig fConfig) throws ServletException {
		System.out.println("------------------------------");
		System.out.println("Init method is called in:"+this.getClass().getName());
		System.out.println("-------------------------------");
	}
	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		System.out.println("doFilter method is called in:"+this.getClass().getName());
		PrintWriter out=response.getWriter();
		HttpServletRequest req=(HttpServletRequest) request;
		//Get the ip address of client machine
		String ipAddress=req.getRemoteAddr();
		
		//Log the ip address and time stamp
		System.out.println("IP Address:"+ipAddress+", Time:"+new Date().toString());
		out.println("Log filter is invoked before<br>");
		chain.doFilter(request, response);
		out.println("Log filter is invoked after<br>");
	}

	public void destroy() {
		System.out.println("------------------------------");
		System.out.println("Destroy method is called in:"+this.getClass().getName());
		System.out.println("-------------------------------");
	}

}
