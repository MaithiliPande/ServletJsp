package com.yash.cms.dao;

import java.util.List;

import com.yash.cms.domain.User;

/**
 * This interface will perform the operation related to users
 * @author maithili.pande
 *
 */
public interface UserDAO {
	/**
	 * This will add user object in the database
	 * @param user
	 */
	public void insert(User user);
	/**
	 * This will delete user record from user database based on provided user id
	 * @param userid of registered user
	 */
	public void delete(Integer userid);
	/**
	 * This will delete user record from user database based on provided user.
	 * @param user object
	 */
	public void delete(User user);
	/**
	 * This will update user record in database base on provided userid
	 * @param userid
	 */
	public void update(Integer userid);
	/**
	 * This will list all the users from table
	 * @return list of users
	 */
	public List<User> list();
}
