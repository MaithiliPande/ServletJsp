package com.yash.cms.domain;
/**
 * This class will work as a model object. Its use is to travel data from one layer to another layer
 * @author maithili.pande
 *
 */
public class User extends Person{
	/**
	 * status of user
	 */
	public Integer status;
	/**
	 * role of user
	 */
	public Integer role;
	/**
	 * username of user
	 */
	public String username;
	/**
	 * password of user
	 */
	public String password;
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getRole() {
		return role;
	}
	public void setRole(Integer role) {
		this.role = role;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

}
