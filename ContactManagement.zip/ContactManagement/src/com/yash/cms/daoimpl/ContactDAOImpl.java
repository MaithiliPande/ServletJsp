package com.yash.cms.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.yash.cms.dao.ContactDAO;
import com.yash.cms.domain.Contact;
import com.yash.cms.util.DBUtil;

public class ContactDAOImpl implements ContactDAO {
	private static Logger logger= Logger.getLogger(ContactDAOImpl.class);
	@Override
	public void insert(Contact contact) {
		String sql="insert into contacts(userid,name,contact,email, address) values(?,?,?,?,?)";
		PreparedStatement pstmt=DBUtil.createPreparedStatement(sql);
		try {
			pstmt.setInt(1, contact.getUserid());
			pstmt.setString(2, contact.getName());
			pstmt.setString(3, contact.getContact());
			pstmt.setString(4, contact.getEmail());
			pstmt.setString(5, contact.getAddress());
			pstmt.execute();
			logger.info("record has been inserted successfully..checkDB");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public List<Contact> list(Integer userid) {
		List<Contact> contacts=new ArrayList<Contact>();
		String sql="select * from contacts where userid=?";
		PreparedStatement pstmt=DBUtil.createPreparedStatement(sql);
		try {
			pstmt.setInt(1, userid);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next())
			{
				Contact contact=new Contact();
				contact.setId(rs.getInt("id"));
				contact.setName(rs.getString("name"));
				contact.setContact(rs.getString("contact"));
				contact.setEmail(rs.getString("email"));
				contact.setAddress(rs.getString("address"));
				contacts.add(contact);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return contacts;
	}

	@Override
	public void delete(Integer id) {
		String sql="delete from contacts where id='"+id+"'";
		PreparedStatement pstmt=DBUtil.createPreparedStatement(sql);
		try {
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void update(Contact contact) {
		String sql="update contacts set name='"+contact.getName()+"',"
									+ " contact='"+contact.getContact()+"',"
									+ "email='"+contact.getEmail()+"',"
									+ "address='"+contact.getAddress()+"'"
									+ "where id='"+contact.getId()+"'";
		PreparedStatement pstmt=DBUtil.createPreparedStatement(sql);
		try {
			pstmt.executeUpdate();
			logger.info(pstmt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public Contact getDetails(Integer id) {
		String sql="select * from contacts where id='"+id+"'";
		Contact contact=null;
		PreparedStatement pstmt=DBUtil.createPreparedStatement(sql);
		try {
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
			{
				contact=new Contact();
				contact.setId(rs.getInt("id"));
				contact.setName(rs.getString("name"));
				contact.setContact(rs.getString("contact"));
				contact.setEmail(rs.getString("email"));
				contact.setAddress(rs.getString("address"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return contact;
		
	}

	@Override
	public List<Contact> search(Integer userid, String searchText) {
		List<Contact> contacts=new ArrayList<Contact>();
		String text="%"+searchText+"%";
		String sql="SELECT * FROM contacts WHERE userid=? AND (name LIKE ?  OR contact LIKE ? OR email LIKE ? OR address LIKE ?)";
		PreparedStatement pstmt=DBUtil.createPreparedStatement(sql);
		try {
			pstmt.setInt(1, userid);
			pstmt.setString(2, text);
			pstmt.setString(3, text);
			pstmt.setString(4, text);
			pstmt.setString(5, text);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next())
			{
				Contact contact=new Contact();
				contact.setId(rs.getInt("id"));
				contact.setName(rs.getString("name"));
				contact.setContact(rs.getString("contact"));
				contact.setEmail(rs.getString("email"));
				contact.setAddress(rs.getString("address"));
				contacts.add(contact);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return contacts;
	}
	

}
