package com.yash.cms.daoimpl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.yash.cms.dao.UserDAO;
import com.yash.cms.domain.User;
import com.yash.cms.util.DBUtil;
/**
 * This class is implementation of UserDAO interface
 * @author maithili.pande
 *
 */
public class UserDAOImpl implements UserDAO {
	private static Logger logger= Logger.getLogger(UserDAOImpl.class);
	User user=new User();
	@Override
	public void insert(User user) {
		String sql="insert into users(name,contact,email,address,username,password)"
				+ " values(?,?,?,?,?,?)";
		PreparedStatement pstmt=DBUtil.createPreparedStatement(sql);
		try {
		pstmt.setString(1, user.getName());
		pstmt.setString(2, user.getContact());
		pstmt.setString(3, user.getEmail());
		pstmt.setString(4, user.getAddress());
		pstmt.setString(5, user.getUsername());
		pstmt.setString(6, user.getPassword());
		pstmt.execute();
		logger.info("user inserted successfully..chechkDB");
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void delete(Integer userid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Integer userid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<User> list() {
		// TODO Auto-generated method stub
		return null;
	}

}
