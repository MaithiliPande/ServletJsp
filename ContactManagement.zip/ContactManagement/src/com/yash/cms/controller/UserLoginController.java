package com.yash.cms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.cms.domain.User;
import com.yash.cms.service.UserService;
import com.yash.cms.serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class UserLoginController
 */
@WebServlet("/UserLoginController")
public class UserLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 private UserService userService=null; 
	 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserLoginController() {
        super();
        userService=new UserServiceImpl();
    }

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		HttpSession session=null;
		User user=userService.userAuthentication(username, password);
		if(user!=null) {
			session=request.getSession(true);
			session.setAttribute("userid", user.getId());
			session.setAttribute("user", user);
			session.setAttribute("username", user.getUsername());
			response.sendRedirect("./guest_dashboard.jsp?msg="+username);
		}
		else {
			response.sendRedirect("./index.jsp?err=Invalid username or password");
		}
	}

}
