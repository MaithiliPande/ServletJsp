package com.yash.cms.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.cms.domain.Contact;
import com.yash.cms.service.ContactService;
import com.yash.cms.serviceimpl.ContactServiceImpl;

/**
 * Servlet implementation class ListContactController
 */
@WebServlet("/ListContactController")
public class ListContactController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ContactService contactService=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListContactController() {
        super();
        contactService=new ContactServiceImpl();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Contact> contacts=contactService.listcontact((Integer) request.getSession().getAttribute("userid"));
		request.setAttribute("contactList", contacts);
		request.getRequestDispatcher("listContacts.jsp").forward(request, response);
	}
	

}
