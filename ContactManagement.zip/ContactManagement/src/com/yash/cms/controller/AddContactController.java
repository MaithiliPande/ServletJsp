package com.yash.cms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.cms.domain.Contact;
import com.yash.cms.service.ContactService;
import com.yash.cms.serviceimpl.ContactServiceImpl;

/**
 * Servlet implementation class AddContactController
 */
@WebServlet("/AddContactController")
public class AddContactController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private ContactService contactService=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddContactController() {
        super();
        contactService=new ContactServiceImpl();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Contact contact=new Contact();
		contact.setUserid((Integer)request.getSession().getAttribute("userid"));
		contact.setName(request.getParameter("name"));
		contact.setContact(request.getParameter("contact"));
		contact.setEmail(request.getParameter("email"));
		contact.setAddress(request.getParameter("address"));
		
		if(request.getParameter("id")!="") {
			contact.setId(Integer.parseInt(request.getParameter("id")));
			contactService.updateContact(contact);
			response.sendRedirect("./contact.jsp?msg=Contact updated");
		}
		else {
			contactService.addContact(contact);
			response.sendRedirect("./contact.jsp?msg=Contact added");
		}
		
		
	}

}
