package com.yash.cms.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.cms.domain.Contact;
import com.yash.cms.service.ContactService;
import com.yash.cms.serviceimpl.ContactServiceImpl;

/**
 * Servlet implementation class SearchContactController
 */
@WebServlet("/SearchContactController")
public class SearchContactController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       ContactService contactService=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchContactController() {
       contactService=new ContactServiceImpl();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer userid=(Integer) request.getSession().getAttribute("userid");
		String searchText=request.getParameter("search");
		List<Contact> contacts=contactService.searchContact(userid,searchText);
		request.setAttribute("contactList", contacts);
		request.getRequestDispatcher("listContacts.jsp?msg=Searched").forward(request, response);
	}

}
