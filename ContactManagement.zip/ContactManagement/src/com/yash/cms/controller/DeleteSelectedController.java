package com.yash.cms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.cms.service.ContactService;
import com.yash.cms.serviceimpl.ContactServiceImpl;



/**
 * Servlet implementation class DeleteSelectedController
 */
@WebServlet("/DeleteSelectedController")
public class DeleteSelectedController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private ContactService contactService=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteSelectedController() {
        super();
        contactService=new ContactServiceImpl();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String[] contactIdArr=request.getParameterValues("cid");
		List<Integer> contactIdList=new ArrayList<Integer>();
		for (String contactId : contactIdArr) {
			contactIdList.add(Integer.parseInt(contactId));
		}
		for (Integer contactid : contactIdList) {
			contactService.deleteContact(contactid);
		}
		request.getRequestDispatcher("ListContactController?msg=Contacts deleted").forward(request, response);
	}

}
