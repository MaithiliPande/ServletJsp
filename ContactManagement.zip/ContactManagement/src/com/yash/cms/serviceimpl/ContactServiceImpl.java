package com.yash.cms.serviceimpl;

import java.util.List;

import org.apache.log4j.Logger;

import com.yash.cms.dao.ContactDAO;
import com.yash.cms.daoimpl.ContactDAOImpl;
import com.yash.cms.domain.Contact;
import com.yash.cms.service.ContactService;

public class ContactServiceImpl implements ContactService {
	private static Logger logger= Logger.getLogger(ContactServiceImpl.class);
	private ContactDAO contactDAO=null;
	

	public ContactServiceImpl() {
		contactDAO=new ContactDAOImpl();
		logger.info("contact service object created:"+contactDAO);
	}


	@Override
	public void addContact(Contact contact) {
		contactDAO.insert(contact);
	}


	@Override
	public List<Contact> listcontact(Integer userid) {
		List<Contact>contacts=contactDAO.list(userid);
		return contacts;
	}


	@Override
	public void deleteContact(Integer id) {
		contactDAO.delete(id);
	}


	@Override
	public void updateContact(Contact contact) {
		contactDAO.update(contact);
	}


	@Override
	public Contact getContactDetails(Integer id) {
		return contactDAO.getDetails(id);
	}


	@Override
	public List<Contact> searchContact(Integer userid, String searchText) {
		return contactDAO.search(userid,searchText);
		
	}

}
