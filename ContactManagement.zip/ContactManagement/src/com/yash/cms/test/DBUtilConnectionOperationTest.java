package com.yash.cms.test;

import com.yash.cms.util.DBUtil;

public class DBUtilConnectionOperationTest {
	public static void main(String[] args) {
//		DBUtil.connection();
	}
}
