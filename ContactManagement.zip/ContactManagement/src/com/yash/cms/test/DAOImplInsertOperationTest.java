package com.yash.cms.test;

import com.yash.cms.dao.UserDAO;
import com.yash.cms.daoimpl.UserDAOImpl;

public class DAOImplInsertOperationTest {
	public static void main(String[] args) {
		UserDAO userDAO=new UserDAOImpl();
		
	}
}
