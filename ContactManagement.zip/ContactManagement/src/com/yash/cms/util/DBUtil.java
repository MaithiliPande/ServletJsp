package com.yash.cms.util;
/**
 * This class will perform operation related to database like connection, 
 * disconnection, providing Prepared Statement object and ResultSet object.
 * This class will be responsible to have transaction complete operation as well 
 * like closing connection, Prepared statement object etc.
 * @author maithili.pande
 *
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.yash.cms.domain.User;

public class DBUtil {
	private static Logger logger= Logger.getLogger(DBUtil.class);
	static String driverClassName="com.mysql.jdbc.Driver";
	static String url="jdbc:mysql://localhost/contact_management";
	static String user="root";
	static String pwd="root";
	static Connection con=null;
	static PreparedStatement pstmt=null;
	//User userDomain=new User();
	static {

		try {
			Class c=Class.forName(driverClassName);
			logger.info("Class:-"+c);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This method should return the connection object based on url, username, password
	 * provided to DriverManager.getConnection() method
	 * @return connection object con
	 */
	public static Connection connection() {
		try {
			con=DriverManager.getConnection(url, user, pwd);
			logger.info("con:-"+con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
	
	/**
	 * This method will return the PreparedStatement object based on the sql provided.
	 * This method should have call for connection because when you need transaction 
	 * that time you will require connection object 
	 * @sql is any query
	 * @return PreparedStatement object
	 */
	public static PreparedStatement createPreparedStatement(String sql) {
		connection();
		try {
			pstmt=con.prepareStatement(sql);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pstmt;
	}
	
	/**
	 * This method will close connection
	 */
	public static void closeConnection() {
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This method will close prepared statement
	 */
	public static void closePreparedStatement() {
		try {
			pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
