package com.yash.listener;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;

/**
 * Application Lifecycle Listener implementation class MyHttpSessionAttributeListener
 *
 */
@WebListener
public class MyHttpSessionAttributeListener implements HttpSessionAttributeListener {

  
    public void attributeAdded(HttpSessionBindingEvent httpSessionBindingEvent)  { 
    	System.out.println("\n#####################\n");
    	System.out.println("attributeAdded method is called in "+this.getClass().getName());
    	System.out.println("Newly added attribute name is :"+httpSessionBindingEvent.getName()+
    			", value:"+httpSessionBindingEvent.getValue());
    	System.out.println("\n#####################\n");
    }

    public void attributeRemoved(HttpSessionBindingEvent httpSessionBindingEvent)  { 
    	System.out.println("\n#####################\n");
    	System.out.println("attributeRemoved method is called in "+this.getClass().getName());
    	System.out.println("Removed attribute name is :"+httpSessionBindingEvent.getName()+
    			", value:"+httpSessionBindingEvent.getValue());
    	System.out.println("\n#####################\n");
    }

    public void attributeReplaced(HttpSessionBindingEvent httpSessionBindingEvent)  { 
    	System.out.println("\n#####################\n");
    	System.out.println("attributeReplaced method is called in "+this.getClass().getName());
    	System.out.println("Replaced attribute name is :"+httpSessionBindingEvent.getName()+
    			" value:"+httpSessionBindingEvent.getValue());
    	System.out.println("\n#####################\n");
    }
	
}
