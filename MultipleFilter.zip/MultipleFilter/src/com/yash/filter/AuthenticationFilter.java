package com.yash.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet Filter implementation class AuthenticationFilter
 */

public class AuthenticationFilter implements Filter {

   
	public void destroy() {
		System.out.println("---------------------");
		System.out.println("Destroy method is called in:"+this.getClass().getName());
		System.out.println("---------------------");
	}

	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		System.out.println("----------------------");
		System.out.println("doFilter method is called in:"+this.getClass().getName());
		PrintWriter out=response.getWriter();
		HttpServletRequest req=(HttpServletRequest) request;
		HttpServletResponse res=(HttpServletResponse) response;
		String uName=req.getParameter("username");
		String pwd=req.getParameter("password");
		if(uName.equals("admin") && pwd.equals("admin"))
		{
			chain.doFilter(request, response);
		}
		else
		{
			out.println("Wrong credentials");
			 res.sendRedirect("index.html");
			
		}
	}

	
	public void init(FilterConfig fConfig) throws ServletException {
		System.out.println("---------------------");
		System.out.println("Init method is called in:"+this.getClass().getName());
		System.out.println("---------------------");
	}

}
